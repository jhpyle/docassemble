[BOLDCENTER] Summary of Benefits

${ client } is entitled to
benefits plan ${ benefits }.
