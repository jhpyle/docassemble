from docassemble.base.functions import process_action

__all__ = ['process_action']
