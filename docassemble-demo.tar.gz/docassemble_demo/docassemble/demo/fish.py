from docassemble.base.core import DAObject

class Halibut(DAObject):
    pass

class Food(DAObject):
    pass
