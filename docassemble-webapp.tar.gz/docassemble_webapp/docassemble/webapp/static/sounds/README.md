# notification-click.mp3

Title: Click2

About: Short clicking sound as of a button or small switch

Recorded by: Sebastian

License: [Creative Commons Attribution 3.0]

Downloaded from: [SoundBible.com](http://soundbible.com/1705-Click2.html)

No changes have been made except for conversion to OGG format.

# notification-click-off.mp3

Title: Button Click Off

About: Sound of a button click off. great computer sound click effect,
or flash sound effect.

Recorded by: Mike Koenig 

License: [Creative Commons Attribution 3.0]

Downloaded from: [SoundBible.com](http://soundbible.com/1294-Button-Click-Off.html)

No changes have been made except for conversion to OGG format.

# notification-click-on.mp3

Title: Click On

About: Cool computer button click sound. great for an operating system
or web page. great on or off toggle sound.

Recorded by: Mike Koenig 

License: [Creative Commons Attribution 3.0]

Downloaded from: [SoundBible.com](http://soundbible.com/1280-Click-On.html)

No changes have been made except for conversion to OGG format.

# notification-stapler.mp3

Title: Stapler

About: Stapler clicking and stapling sound effect. office or business
sound effect.

Recorded by: earthcalling

License: Public Domain

Downloaded from: [SoundBible.com](http://soundbible.com/1536-Stapler.html)

No changes have been made except for conversion to OGG format.

# notification-snap.mp3

Title: Snap

About: Very nice clicks, pops, or snaps.

Recorded by: Caroline Ford

License: [Creative Commons Attribution 3.0]

Downloaded from: [SoundBible.com](http://soundbible.com/933-Snap.html)

No changes have been made except for conversion to OGG format.

[Creative Commons Attribution 3.0]: https://creativecommons.org/licenses/by/3.0/legalcode
